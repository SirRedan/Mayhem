import pygame


def thrustcreate():
    image = pygame.image.load("images/thrust.png").convert_alpha()
    rect = image.get_rect()
    width = rect.right // 8
    height = rect.bottom // 8
    thrustlist = []
    for i in range(8):
        for j in range(8):
            thrustlist.append(image.subsurface(j* width, i * width, width, height))

    return thrustlist

